# Application Development for Mobile Devices - Project
## FIT Timetable

#### Authors:
- Alena Tesařová <xtesar36@stud.fit.vutbr.cz>
- Dominik Harmim <xharmi00@stud.fit.vutbr.cz>
- Petr Kohout <xkohou14@stud.fit.vutbr.cz>
